package com.kaikeba.dao;

import com.kaikeba.beans.Dept;

public interface DeptMapper {
   public Dept deptFindById(Integer deptno);
}
