package com.kaikeba.dao;

import java.util.List;

public interface EmpMapper {
 public  List empFind();
}
