package com.kaikeba.service;

public interface SqlSession {
	
	 public int save(String sql)throws Exception;

}
