package com.kaikeba.dao;

import java.util.List;

import com.kaikeba.beans.Employee;

public interface EmpMapper {
 public  List empFind(Employee e);
}
