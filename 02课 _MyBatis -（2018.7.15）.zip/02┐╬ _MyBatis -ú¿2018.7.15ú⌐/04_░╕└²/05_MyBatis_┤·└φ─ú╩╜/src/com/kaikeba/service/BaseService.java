package com.kaikeba.service;
/*
 * 
 * 只有需要被监控的行为才有资格
 * 在这里声明 
 * 
 */
public interface BaseService {
     public void eat();
     public void wc();
}
