package com.kaikeba.dao;

public interface EmpMapper {

}
