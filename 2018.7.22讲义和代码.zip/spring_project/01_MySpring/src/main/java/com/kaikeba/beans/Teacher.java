package com.kaikeba.beans;

public class Teacher {
       private String tname;
      
       

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}
       
}
