package com.kaikeba.service;

public interface BaseService {
        public String doSome();
}
