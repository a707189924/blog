package com.kaikeba.serviceImpl;

import com.kaikeba.service.BaseService;

public class ISomeService implements BaseService {

	public String doSome() {
		// TODO Auto-generated method stub
		return "Hello mike";//增强效果，doSome方法返回值都是大写
	}

}
