package com.kaikeba.serviceImpl;

import com.kaikeba.service.BaseService;

public class Gog implements BaseService {

	public void eat() {
		System.out.println("啃骨头");

	}

	public void wc() {
		System.out.println("嘘嘘....");

	}

}
