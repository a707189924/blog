package com.kaikeba.service;

public interface BaseService {
       public void eat();//JoinCut 连接点
       public void wc();//JoinCut 连接点
}
